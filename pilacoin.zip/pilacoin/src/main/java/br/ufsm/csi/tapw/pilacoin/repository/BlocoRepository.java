package br.ufsm.csi.tapw.pilacoin.repository;

public interface BlocoRepository {
}
