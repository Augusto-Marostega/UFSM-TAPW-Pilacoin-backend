package br.ufsm.csi.tapw.pilacoin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PilacoinApplication {
	public static void main(String[] args) {
		SpringApplication.run(PilacoinApplication.class, args);
	}

}
